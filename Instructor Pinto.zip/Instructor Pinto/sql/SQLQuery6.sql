CREATE DATABASE Conciertos;
GO
USE Conciertos;
GO

CREATE TABLE Artistas (
    ArtistaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Genero NVARCHAR(50)
);

CREATE TABLE Eventos (
    EventoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Lugar NVARCHAR(100),
    Fecha DATE
);

CREATE TABLE Entradas (
    EntradaID INT PRIMARY KEY IDENTITY,
    EventoID INT,
    Precio DECIMAL(10,2),
    Disponibles INT,
    FOREIGN KEY (EventoID) REFERENCES Eventos(EventoID)
);

CREATE TABLE ArtistaEvento (
    ID INT PRIMARY KEY IDENTITY,
    ArtistaID INT,
    EventoID INT,
    FOREIGN KEY (ArtistaID) REFERENCES Artistas(ArtistaID),
    FOREIGN KEY (EventoID) REFERENCES Eventos(EventoID)
);
