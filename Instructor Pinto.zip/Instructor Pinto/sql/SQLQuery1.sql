CREATE DATABASE Aeropuerto;
GO
USE Aeropuerto;
GO

CREATE TABLE Pasajeros (
    PasajeroID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Documento VARCHAR(20) UNIQUE
);

CREATE TABLE Aviones (
    AvionID INT PRIMARY KEY IDENTITY,
    Modelo NVARCHAR(100),
    Capacidad INT
);

CREATE TABLE Vuelos (
    VueloID INT PRIMARY KEY IDENTITY,
    AvionID INT,
    Origen NVARCHAR(100),
    Destino NVARCHAR(100),
    Fecha DATE,
    FOREIGN KEY (AvionID) REFERENCES Aviones(AvionID)
);

CREATE TABLE PasajeroVuelo (
    ID INT PRIMARY KEY IDENTITY,
    PasajeroID INT,
    VueloID INT,
    Asiento VARCHAR(5),
    FOREIGN KEY (PasajeroID) REFERENCES Pasajeros(PasajeroID),
    FOREIGN KEY (VueloID) REFERENCES Vuelos(VueloID)
);
