CREATE DATABASE Parqueadero;
GO
USE Parqueadero;
GO

CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Vehiculos (
    VehiculoID INT PRIMARY KEY IDENTITY,
    ClienteID INT,
    Placa VARCHAR(10) UNIQUE,
    Modelo NVARCHAR(50),
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID)
);

CREATE TABLE Parqueos (
    ParqueoID INT PRIMARY KEY IDENTITY,
    VehiculoID INT,
    FechaEntrada DATETIME,
    FechaSalida DATETIME NULL,
    FOREIGN KEY (VehiculoID) REFERENCES Vehiculos(VehiculoID)
);
