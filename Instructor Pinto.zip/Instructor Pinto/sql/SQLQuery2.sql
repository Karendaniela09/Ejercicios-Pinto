CREATE DATABASE Universidad;
GO
USE Universidad;
GO

CREATE TABLE Estudiantes (
    EstudianteID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Edad INT
);

CREATE TABLE Profesores (
    ProfesorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Area NVARCHAR(100)
);

CREATE TABLE Asignaturas (
    AsignaturaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Creditos INT
);

CREATE TABLE Matriculas (
    MatriculaID INT PRIMARY KEY IDENTITY,
    EstudianteID INT,
    AsignaturaID INT,
    ProfesorID INT,
    Semestre VARCHAR(10),
    FOREIGN KEY (EstudianteID) REFERENCES Estudiantes(EstudianteID),
    FOREIGN KEY (AsignaturaID) REFERENCES Asignaturas(AsignaturaID),
    FOREIGN KEY (ProfesorID) REFERENCES Profesores(ProfesorID)
);
