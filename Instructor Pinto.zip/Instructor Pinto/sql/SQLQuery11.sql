CREATE DATABASE Editorial;
GO
USE Editorial;
GO

CREATE TABLE Autores (
    AutorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Nacionalidad NVARCHAR(50)
);

CREATE TABLE Libros (
    LibroID INT PRIMARY KEY IDENTITY,
    Titulo NVARCHAR(100),
    Genero NVARCHAR(50),
    AutorID INT,
    FOREIGN KEY (AutorID) REFERENCES Autores(AutorID)
);

CREATE TABLE Publicaciones (
    PublicacionID INT PRIMARY KEY IDENTITY,
    LibroID INT,
    FechaPublicacion DATE,
    Editorial NVARCHAR(100),
    FOREIGN KEY (LibroID) REFERENCES Libros(LibroID)
);
