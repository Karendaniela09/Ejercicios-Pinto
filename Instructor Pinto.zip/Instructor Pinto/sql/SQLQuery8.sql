CREATE DATABASE Banco;
GO
USE Banco;
GO

CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Documento VARCHAR(20) UNIQUE
);

CREATE TABLE Cuentas (
    CuentaID INT PRIMARY KEY IDENTITY,
    ClienteID INT,
    Tipo NVARCHAR(50),
    Saldo DECIMAL(12,2),
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID)
);

CREATE TABLE Transacciones (
    TransaccionID INT PRIMARY KEY IDENTITY,
    CuentaID INT,
    Fecha DATETIME,
    Tipo NVARCHAR(50),
    Monto DECIMAL(12,2),
    FOREIGN KEY (CuentaID) REFERENCES Cuentas(CuentaID)
);
