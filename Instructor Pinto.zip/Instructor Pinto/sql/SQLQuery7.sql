CREATE DATABASE Veterinaria;
GO
USE Veterinaria;
GO

CREATE TABLE Duennos (
    DuennosID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Mascotas (
    MascotaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Especie NVARCHAR(50),
    Edad INT,
    DuennosID INT,
    FOREIGN KEY (DuennosID) REFERENCES Duennos(DuennosID)
);

CREATE TABLE Consultas (
    ConsultaID INT PRIMARY KEY IDENTITY,
    MascotaID INT,
    Fecha DATE,
    Diagnostico NVARCHAR(255),
    FOREIGN KEY (MascotaID) REFERENCES Mascotas(MascotaID)
);
