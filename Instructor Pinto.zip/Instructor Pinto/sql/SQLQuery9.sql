CREATE DATABASE EscuelaMusica;
GO
USE EscuelaMusica;
GO

CREATE TABLE Alumnos (
    AlumnoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Edad INT
);

CREATE TABLE Profesores (
    ProfesorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Instrumento NVARCHAR(50)
);

CREATE TABLE Clases (
    ClaseID INT PRIMARY KEY IDENTITY,
    AlumnoID INT,
    ProfesorID INT,
    Fecha DATE,
    Hora TIME,
    FOREIGN KEY (AlumnoID) REFERENCES Alumnos(AlumnoID),
    FOREIGN KEY (ProfesorID) REFERENCES Profesores(ProfesorID)
);
