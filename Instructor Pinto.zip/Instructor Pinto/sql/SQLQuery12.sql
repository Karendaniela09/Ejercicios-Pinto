CREATE DATABASE Farmacia;
GO
USE Farmacia;
GO

CREATE TABLE Proveedores (
    ProveedorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Medicamentos (
    MedicamentoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Precio DECIMAL(10,2),
    ProveedorID INT,
    FOREIGN KEY (ProveedorID) REFERENCES Proveedores(ProveedorID)
);

CREATE TABLE Ventas (
    VentaID INT PRIMARY KEY IDENTITY,
    MedicamentoID INT,
    Cantidad INT,
    Fecha DATE,
    FOREIGN KEY (MedicamentoID) REFERENCES Medicamentos(MedicamentoID)
);
