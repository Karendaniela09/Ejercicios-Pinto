/* Crear Base de Datos */
CREATE DATABASE Gimnasio;
GO
USE Gimnasio;
GO

/* ======================
   TABLA CLIENTES
   ====================== */
CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Edad INT NOT NULL
);

/* ======================
   TABLA ENTRENADORES
   ====================== */
CREATE TABLE Entrenadores (
    EntrenadorID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Especialidad NVARCHAR(100) NOT NULL
);

/* ======================
   TABLA RUTINAS
   ====================== */
CREATE TABLE Rutinas (
    RutinaID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Descripcion NVARCHAR(255)
);

/* ======================
   TABLA CLASES
   ====================== */
CREATE TABLE Clases (
    ClaseID INT PRIMARY KEY IDENTITY(1,1),
    ClienteID INT NOT NULL,
    EntrenadorID INT NOT NULL,
    RutinaID INT NOT NULL,
    DiaSemana NVARCHAR(20) NOT NULL,
    Hora TIME NOT NULL,
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID),
    FOREIGN KEY (EntrenadorID) REFERENCES Entrenadores(EntrenadorID),
    FOREIGN KEY (RutinaID) REFERENCES Rutinas(RutinaID)
);

CREATE DATABASE Aeropuerto;
GO
USE Aeropuerto;
GO

CREATE TABLE Pasajeros (
    PasajeroID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Documento VARCHAR(20) UNIQUE
);

CREATE TABLE Aviones (
    AvionID INT PRIMARY KEY IDENTITY,
    Modelo NVARCHAR(100),
    Capacidad INT
);

CREATE TABLE Vuelos (
    VueloID INT PRIMARY KEY IDENTITY,
    AvionID INT,
    Origen NVARCHAR(100),
    Destino NVARCHAR(100),
    Fecha DATE,
    FOREIGN KEY (AvionID) REFERENCES Aviones(AvionID)
);

CREATE TABLE PasajeroVuelo (
    ID INT PRIMARY KEY IDENTITY,
    PasajeroID INT,
    VueloID INT,
    Asiento VARCHAR(5),
    FOREIGN KEY (PasajeroID) REFERENCES Pasajeros(PasajeroID),
    FOREIGN KEY (VueloID) REFERENCES Vuelos(VueloID)
);

CREATE DATABASE Universidad;
GO
USE Universidad;
GO

CREATE TABLE Estudiantes (
    EstudianteID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Edad INT
);

CREATE TABLE Profesores (
    ProfesorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Area NVARCHAR(100)
);

CREATE TABLE Asignaturas (
    AsignaturaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Creditos INT
);

CREATE TABLE Matriculas (
    MatriculaID INT PRIMARY KEY IDENTITY,
    EstudianteID INT,
    AsignaturaID INT,
    ProfesorID INT,
    Semestre VARCHAR(10),
    FOREIGN KEY (EstudianteID) REFERENCES Estudiantes(EstudianteID),
    FOREIGN KEY (AsignaturaID) REFERENCES Asignaturas(AsignaturaID),
    FOREIGN KEY (ProfesorID) REFERENCES Profesores(ProfesorID)
);

CREATE DATABASE Museo;
GO
USE Museo;
GO

CREATE TABLE Artistas (
    ArtistaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Nacionalidad NVARCHAR(50)
);

CREATE TABLE Obras (
    ObraID INT PRIMARY KEY IDENTITY,
    Titulo NVARCHAR(100),
    Anio INT,
    ArtistaID INT,
    FOREIGN KEY (ArtistaID) REFERENCES Artistas(ArtistaID)
);

CREATE TABLE Exposiciones (
    ExposicionID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    FechaInicio DATE,
    FechaFin DATE
);

CREATE TABLE ObraExposicion (
    ID INT PRIMARY KEY IDENTITY,
    ObraID INT,
    ExposicionID INT,
    FOREIGN KEY (ObraID) REFERENCES Obras(ObraID),
    FOREIGN KEY (ExposicionID) REFERENCES Exposiciones(ExposicionID)
);

CREATE DATABASE EmpresaSoftware;
GO
USE EmpresaSoftware;
GO

CREATE TABLE Empleados (
    EmpleadoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Cargo NVARCHAR(50)
);

CREATE TABLE Proyectos (
    ProyectoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Cliente NVARCHAR(100)
);

CREATE TABLE Asignaciones (
    AsignacionID INT PRIMARY KEY IDENTITY,
    EmpleadoID INT,
    ProyectoID INT,
    Rol NVARCHAR(50),
    FOREIGN KEY (EmpleadoID) REFERENCES Empleados(EmpleadoID),
    FOREIGN KEY (ProyectoID) REFERENCES Proyectos(ProyectoID)
);
CREATE DATABASE Veterinaria;
GO
USE Veterinaria;
GO

CREATE TABLE Duennos (
    DuennosID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Mascotas (
    MascotaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Especie NVARCHAR(50),
    Edad INT,
    DuennosID INT,
    FOREIGN KEY (DuennosID) REFERENCES Duennos(DuennosID)
);

CREATE TABLE Consultas (
    ConsultaID INT PRIMARY KEY IDENTITY,
    MascotaID INT,
    Fecha DATE,
    Diagnostico NVARCHAR(255),
    FOREIGN KEY (MascotaID) REFERENCES Mascotas(MascotaID)
);
CREATE DATABASE EscuelaMusica;
GO
USE EscuelaMusica;
GO

CREATE TABLE Alumnos (
    AlumnoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Edad INT
);

CREATE TABLE Profesores (
    ProfesorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Instrumento NVARCHAR(50)
);

CREATE TABLE Clases (
    ClaseID INT PRIMARY KEY IDENTITY,
    AlumnoID INT,
    ProfesorID INT,
    Fecha DATE,
    Hora TIME,
    FOREIGN KEY (AlumnoID) REFERENCES Alumnos(AlumnoID),
    FOREIGN KEY (ProfesorID) REFERENCES Profesores(ProfesorID)
);
CREATE DATABASE Farmacia;
GO
USE Farmacia;
GO

CREATE TABLE Proveedores (
    ProveedorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Medicamentos (
    MedicamentoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Precio DECIMAL(10,2),
    ProveedorID INT,
    FOREIGN KEY (ProveedorID) REFERENCES Proveedores(ProveedorID)
);

CREATE TABLE Ventas (
    VentaID INT PRIMARY KEY IDENTITY,
    MedicamentoID INT,
    Cantidad INT,
    Fecha DATE,
    FOREIGN KEY (MedicamentoID) REFERENCES Medicamentos(MedicamentoID)
);
CREATE DATABASE Editorial;
GO
USE Editorial;
GO

CREATE TABLE Autores (
    AutorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Nacionalidad NVARCHAR(50)
);

CREATE TABLE Libros (
    LibroID INT PRIMARY KEY IDENTITY,
    Titulo NVARCHAR(100),
    Genero NVARCHAR(50),
    AutorID INT,
    FOREIGN KEY (AutorID) REFERENCES Autores(AutorID)
);

CREATE TABLE Publicaciones (
    PublicacionID INT PRIMARY KEY IDENTITY,
    LibroID INT,
    FechaPublicacion DATE,
    Editorial NVARCHAR(100),
    FOREIGN KEY (LibroID) REFERENCES Libros(LibroID)
);
CREATE DATABASE ClubDeportivo;
GO
USE ClubDeportivo;
GO

CREATE TABLE Jugadores (
    JugadorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Posicion NVARCHAR(50)
);

CREATE TABLE Equipos (
    EquipoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Ciudad NVARCHAR(50)
);

CREATE TABLE Partidos (
    PartidoID INT PRIMARY KEY IDENTITY,
    EquipoLocalID INT,
    EquipoVisitanteID INT,
    Fecha DATE,
    FOREIGN KEY (EquipoLocalID) REFERENCES Equipos(EquipoID),
    FOREIGN KEY (EquipoVisitanteID) REFERENCES Equipos(EquipoID)
);

CREATE TABLE JugadorEquipo (
    ID INT PRIMARY KEY IDENTITY,
    JugadorID INT,
    EquipoID INT,
    FOREIGN KEY (JugadorID) REFERENCES Jugadores(JugadorID),
    FOREIGN KEY (EquipoID) REFERENCES Equipos(EquipoID)
);
CREATE DATABASE Parqueadero;
GO
USE Parqueadero;
GO

CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Telefono VARCHAR(20)
);

CREATE TABLE Vehiculos (
    VehiculoID INT PRIMARY KEY IDENTITY,
    ClienteID INT,
    Placa VARCHAR(10) UNIQUE,
    Modelo NVARCHAR(50),
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID)
);

CREATE TABLE Parqueos (
    ParqueoID INT PRIMARY KEY IDENTITY,
    VehiculoID INT,
    FechaEntrada DATETIME,
    FechaSalida DATETIME NULL,
    FOREIGN KEY (VehiculoID) REFERENCES Vehiculos(VehiculoID)
);
CREATE DATABASE Conciertos;
GO
USE Conciertos;
GO

CREATE TABLE Artistas (
    ArtistaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Genero NVARCHAR(50)
);

CREATE TABLE Eventos (
    EventoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Lugar NVARCHAR(100),
    Fecha DATE
);

CREATE TABLE Entradas (
    EntradaID INT PRIMARY KEY IDENTITY,
    EventoID INT,
    Precio DECIMAL(10,2),
    Disponibles INT,
    FOREIGN KEY (EventoID) REFERENCES Eventos(EventoID)
);

CREATE TABLE ArtistaEvento (
    ID INT PRIMARY KEY IDENTITY,
    ArtistaID INT,
    EventoID INT,
    FOREIGN KEY (ArtistaID) REFERENCES Artistas(ArtistaID),
    FOREIGN KEY (EventoID) REFERENCES Eventos(EventoID)
);
