
CREATE DATABASE Gimnasio;
GO
USE Gimnasio;
GO

/* ======================
   TABLA CLIENTES
   ====================== */
CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Edad INT NOT NULL
);

/* ======================
   TABLA ENTRENADORES
   ====================== */
CREATE TABLE Entrenadores (
    EntrenadorID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Especialidad NVARCHAR(100) NOT NULL
);

/* ======================
   TABLA RUTINAS
   ====================== */
CREATE TABLE Rutinas (
    RutinaID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Descripcion NVARCHAR(255)
);

/* ======================
   TABLA CLASES
   ====================== */
   CREATE DATABASE Aeropuerto;
GO
USE Aeropuerto;
GO

CREATE TABLE Pasajeros (
    PasajeroID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Documento VARCHAR(20) UNIQUE
);

CREATE TABLE Aviones (
    AvionID INT PRIMARY KEY IDENTITY,
    Modelo NVARCHAR(100),
    Capacidad INT
);

CREATE TABLE Vuelos (
    VueloID INT PRIMARY KEY IDENTITY,
    AvionID INT,
    Origen NVARCHAR(100),
    Destino NVARCHAR(100),
    Fecha DATE,
    FOREIGN KEY (AvionID) REFERENCES Aviones(AvionID)
);

CREATE TABLE PasajeroVuelo (
    ID INT PRIMARY KEY IDENTITY,
    PasajeroID INT,
    VueloID INT,
    Asiento VARCHAR(5),
    FOREIGN KEY (PasajeroID) REFERENCES Pasajeros(PasajeroID),
    FOREIGN KEY (VueloID) REFERENCES Vuelos(VueloID)
);

