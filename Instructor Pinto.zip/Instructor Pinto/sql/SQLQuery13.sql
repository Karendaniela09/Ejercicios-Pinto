CREATE DATABASE ClubDeportivo;
GO
USE ClubDeportivo;
GO

CREATE TABLE Jugadores (
    JugadorID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Posicion NVARCHAR(50)
);

CREATE TABLE Equipos (
    EquipoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Ciudad NVARCHAR(50)
);

CREATE TABLE Partidos (
    PartidoID INT PRIMARY KEY IDENTITY,
    EquipoLocalID INT,
    EquipoVisitanteID INT,
    Fecha DATE,
    FOREIGN KEY (EquipoLocalID) REFERENCES Equipos(EquipoID),
    FOREIGN KEY (EquipoVisitanteID) REFERENCES Equipos(EquipoID)
);

CREATE TABLE JugadorEquipo (
    ID INT PRIMARY KEY IDENTITY,
    JugadorID INT,
    EquipoID INT,
    FOREIGN KEY (JugadorID) REFERENCES Jugadores(JugadorID),
    FOREIGN KEY (EquipoID) REFERENCES Equipos(EquipoID)
);
