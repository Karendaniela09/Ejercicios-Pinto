-- ===================== MER 1: Biblioteca =====================
CREATE DATABASE BibliotecaDB;
USE BibliotecaDB;

CREATE TABLE Autor (
    idAutor INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Libro (
    idLibro INT PRIMARY KEY,
    titulo VARCHAR(100),
    idAutor INT,
    FOREIGN KEY (idAutor) REFERENCES Autor(idAutor)
);

CREATE TABLE Prestamo (
    idPrestamo INT PRIMARY KEY,
    idLibro INT,
    fecha DATE,
    FOREIGN KEY (idLibro) REFERENCES Libro(idLibro)
);

-- ===================== MER 2: Tienda =====================
CREATE DATABASE TiendaDB34;
USE TiendaDB34;

CREATE TABLE Cliente (
    idCliente INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Producto (
    idProducto INT PRIMARY KEY,
    nombre VARCHAR(100),
    precio DECIMAL(10,2)
);

CREATE TABLE Venta (
    idVenta INT PRIMARY KEY,
    idCliente INT,
    idProducto INT,
    FOREIGN KEY (idCliente) REFERENCES Cliente(idCliente),
    FOREIGN KEY (idProducto) REFERENCES Producto(idProducto)
);

-- ===================== MER 3: Universidad =====================
CREATE DATABASE UniversidadDB356;
USE UniversidadDB356;

CREATE TABLE Estudiante (
    idEstudiante INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Curso (
    idCurso INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Inscripcion (
    idInscripcion INT PRIMARY KEY,
    idEstudiante INT,
    idCurso INT,
    FOREIGN KEY (idEstudiante) REFERENCES Estudiante(idEstudiante),
    FOREIGN KEY (idCurso) REFERENCES Curso(idCurso)
);

-- ===================== MER 4: Hospital =====================
CREATE DATABASE HospitalDB356;
USE HospitalDB356;

CREATE TABLE Doctor (
    idDoctor INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Paciente (
    idPaciente INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Cita (
    idCita INT PRIMARY KEY,
    idDoctor INT,
    idPaciente INT,
    fecha DATE,
    FOREIGN KEY (idDoctor) REFERENCES Doctor(idDoctor),
    FOREIGN KEY (idPaciente) REFERENCES Paciente(idPaciente)
);

-- ===================== MER 5: Cine =====================
CREATE DATABASE CineDB356;
USE CineDB356;

CREATE TABLE Pelicula (
    idPelicula INT PRIMARY KEY,
    titulo VARCHAR(100)
);

CREATE TABLE Sala (
    idSala INT PRIMARY KEY,
    numero INT
);

CREATE TABLE Funcion (
    idFuncion INT PRIMARY KEY,
    idPelicula INT,
    idSala INT,
    fecha DATE,
    FOREIGN KEY (idPelicula) REFERENCES Pelicula(idPelicula),
    FOREIGN KEY (idSala) REFERENCES Sala(idSala)
);

-- ===================== MER 6: Restaurante =====================
CREATE DATABASE RestauranteDB356;
USE RestauranteDB356;

CREATE TABLE Mesa (
    idMesa INT PRIMARY KEY,
    numero INT
);

CREATE TABLE Cliente (
    idCliente INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Reserva (
    idReserva INT PRIMARY KEY,
    idMesa INT,
    idCliente INT,
    fecha DATE,
    FOREIGN KEY (idMesa) REFERENCES Mesa(idMesa),
    FOREIGN KEY (idCliente) REFERENCES Cliente(idCliente)
);

-- ===================== MER 7: Banco =====================
CREATE DATABASE BancoDB356;
USE BancoDB356;

CREATE TABLE Cliente (
    idCliente INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Cuenta (
    idCuenta INT PRIMARY KEY,
    saldo DECIMAL(10,2),
    idCliente INT,
    FOREIGN KEY (idCliente) REFERENCES Cliente(idCliente)
);

CREATE TABLE Transaccion (
    idTransaccion INT PRIMARY KEY,
    idCuenta INT,
    monto DECIMAL(10,2),
    FOREIGN KEY (idCuenta) REFERENCES Cuenta(idCuenta)
);

-- ===================== MER 8: Aerolinea =====================
CREATE DATABASE AerolineaDB356;
USE AerolineaDB356;

CREATE TABLE Avion (
    idAvion INT PRIMARY KEY,
    modelo VARCHAR(100)
);

CREATE TABLE Vuelo (
    idVuelo INT PRIMARY KEY,
    idAvion INT,
    destino VARCHAR(100),
    FOREIGN KEY (idAvion) REFERENCES Avion(idAvion)
);

CREATE TABLE Boleto (
    idBoleto INT PRIMARY KEY,
    idVuelo INT,
    pasajero VARCHAR(100),
    FOREIGN KEY (idVuelo) REFERENCES Vuelo(idVuelo)
);

-- ===================== MER 9: Escuela =====================
CREATE DATABASE EscuelaDB356;
USE EscuelaDB356;

CREATE TABLE Profesor (
    idProfesor INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Materia (
    idMateria INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Clase (
    idClase INT PRIMARY KEY,
    idProfesor INT,
    idMateria INT,
    FOREIGN KEY (idProfesor) REFERENCES Profesor(idProfesor),
    FOREIGN KEY (idMateria) REFERENCES Materia(idMateria)
);

-- ===================== MER 10: Hotel =====================
CREATE DATABASE HotelDB356;
USE HotelDB356;

CREATE TABLE Habitacion (
    idHabitacion INT PRIMARY KEY,
    numero INT
);

CREATE TABLE Huesped (
    idHuesped INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Reserva (
    idReserva INT PRIMARY KEY,
    idHabitacion INT,
    idHuesped INT,
    fecha DATE,
    FOREIGN KEY (idHabitacion) REFERENCES Habitacion(idHabitacion),
    FOREIGN KEY (idHuesped) REFERENCES Huesped(idHuesped)
);

-- ===================== MER 11: Empresa =====================
CREATE DATABASE EmpresaDB356;
USE EmpresaDB356;

CREATE TABLE Empleado (
    idEmpleado INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Departamento (
    idDepartamento INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Asignacion (
    idAsignacion INT PRIMARY KEY,
    idEmpleado INT,
    idDepartamento INT,
    FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado),
    FOREIGN KEY (idDepartamento) REFERENCES Departamento(idDepartamento)
);

-- ===================== MER 12: Musica =====================
CREATE DATABASE MusicaDB356;
USE MusicaDB356;

CREATE TABLE Artista (
    idArtista INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Album (
    idAlbum INT PRIMARY KEY,
    titulo VARCHAR(100),
    idArtista INT,
    FOREIGN KEY (idArtista) REFERENCES Artista(idArtista)
);

CREATE TABLE Cancion (
    idCancion INT PRIMARY KEY,
    titulo VARCHAR(100),
    idAlbum INT,
    FOREIGN KEY (idAlbum) REFERENCES Album(idAlbum)
);

-- ===================== MER 13: Veterinaria =====================
CREATE DATABASE VeterinariaDB356;
USE VeterinariaDB356;

CREATE TABLE Mascota (
    idMascota INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Dueno (
    idDueno INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE Consulta (
    idConsulta INT PRIMARY KEY,
    idMascota INT,
    idDueno INT,
    fecha DATE,
    FOREIGN KEY (idMascota) REFERENCES Mascota(idMascota),
    FOREIGN KEY (idDueno) REFERENCES Dueno(idDueno)
);

-- ========================================= PAQUETERIA========================

CREATE DATABASE PaqueteriaDB;
USE PaqueteriaDB;

CREATE TABLE Cliente (
    idCliente INT PRIMARY KEY,
    nombre VARCHAR(100),
    direccion VARCHAR(150)
);

CREATE TABLE Paquete (
    idPaquete INT PRIMARY KEY,
    descripcion VARCHAR(150),
    peso DECIMAL(10,2),
    idCliente INT,
    FOREIGN KEY (idCliente) REFERENCES Cliente(idCliente)
);

CREATE TABLE Envio (
    idEnvio INT PRIMARY KEY,
    idPaquete INT,
    fechaEnvio DATE,
    destino VARCHAR(150),
    FOREIGN KEY (idPaquete) REFERENCES Paquete(idPaquete)
);
