CREATE DATABASE Museo;
GO
USE Museo;
GO

CREATE TABLE Artistas (
    ArtistaID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Nacionalidad NVARCHAR(50)
);

CREATE TABLE Obras (
    ObraID INT PRIMARY KEY IDENTITY,
    Titulo NVARCHAR(100),
    Anio INT,
    ArtistaID INT,
    FOREIGN KEY (ArtistaID) REFERENCES Artistas(ArtistaID)
);

CREATE TABLE Exposiciones (
    ExposicionID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    FechaInicio DATE,
    FechaFin DATE
);

CREATE TABLE ObraExposicion (
    ID INT PRIMARY KEY IDENTITY,
    ObraID INT,
    ExposicionID INT,
    FOREIGN KEY (ObraID) REFERENCES Obras(ObraID),
    FOREIGN KEY (ExposicionID) REFERENCES Exposiciones(ExposicionID)
);
