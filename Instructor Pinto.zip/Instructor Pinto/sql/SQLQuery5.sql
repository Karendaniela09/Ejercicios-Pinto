CREATE DATABASE EmpresaSoftware;
GO
USE EmpresaSoftware;
GO

CREATE TABLE Empleados (
    EmpleadoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Cargo NVARCHAR(50)
);

CREATE TABLE Proyectos (
    ProyectoID INT PRIMARY KEY IDENTITY,
    Nombre NVARCHAR(100),
    Cliente NVARCHAR(100)
);

CREATE TABLE Asignaciones (
    AsignacionID INT PRIMARY KEY IDENTITY,
    EmpleadoID INT,
    ProyectoID INT,
    Rol NVARCHAR(50),
    FOREIGN KEY (EmpleadoID) REFERENCES Empleados(EmpleadoID),
    FOREIGN KEY (ProyectoID) REFERENCES Proyectos(ProyectoID)
);
